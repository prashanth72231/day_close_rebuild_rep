# Day close — business rules, decisions, and sample result

## Business rules retained from `day_close.php`

1. A store/date cannot close while any bill for that store and business date has status `H`.
2. Only completed (`C`) bills contribute to totals. Voided (`V`) bills are ignored.
3. Tender totals are grouped into CASH, CARD, and UPI. Refund tender amounts are stored positive and are subtracted; sale amounts are added.
4. MRP is GST-inclusive. For each bill item, line value is `qty × mrp − line discount`; GST is calculated on that line as `line − line / (1 + GST rate / 100)`, rounded to two decimals per line. Refund line value and GST are negated. Gross sales includes GST; finance SALES excludes GST.
5. Card variance is POS CARD total minus the manager-entered card-machine total. The allowed absolute variance is Rs 1.00, inclusive.
6. Loyalty applies only to completed SALE bills with a non-empty customer mobile. Points are floor(bill `net_amount` / 100), capped at 500 per bill. Refunds earn no points.
7. A successful close writes one day-close record and five finance interface rows: CASH, CARD, UPI, SALES (excluding GST), and GST.
8. All money uses decimal arithmetic. Finance rows and the close record are committed together; failed validations leave no partial changes.

## Legacy defects/risks corrected

| Legacy behavior | Production risk | Rebuild change |
|---|---|---|
| `BETWEEN '$date' AND '$date'` compares a DATETIME to midnight at both ends, effectively missing almost the entire business date. | Held bills later in the day may not block close; sales/tenders/loyalty may be omitted. | Use a timezone-aware half-open interval `[date 00:00, next date 00:00)`. |
| Card check rejects only `variance > 1`, not `variance < -1`. | A large shortage (POS card total below the machine slip) can pass. | Reject when `abs(variance) > 1.00`; exactly ±Rs 1 is accepted. |
| Close, loyalty updates, and finance inserts are independent unchecked SQL statements. | Partial close, duplicate finance postings, or loyalty changes without a close if a later statement fails. | One database transaction; validations run before writes; unique store/date close constraint; store-row lock serializes competing requests. |
| Raw POST values are interpolated into SQL. | SQL injection and malformed input risks. | DRF validation and ORM parameterization. |
| Floating-point/PHP numeric coercion is used for money and GST. | Binary rounding inaccuracies and inconsistent totals. | `Decimal` throughout; GST rounded half-up to 2 decimals per line. |

## Questions for the business (not silently changed)

1. The PHP updates loyalty only when a matching `loyalty` row already exists. Should a missing loyalty account be created, rejected, or silently skipped? The rebuild preserves the legacy behavior (skip missing row).
2. Tender types outside CASH/CARD/UPI are silently ignored by the PHP. Are there additional valid tenders (for example, wallets or gift cards) that should be posted to finance? The rebuild currently preserves the three known tender buckets and ignores unknown types.
3. The PHP checks held bills only, while voided bills are excluded from calculations. Are there other bill states (pending, cancelled, reopened) that should block close?
4. Is the store's business-day timezone always the configured Django timezone (`Asia/Kolkata` here), or should timezone be stored per store?
5. Should the finance interface use gross SALES or net-of-GST SALES? The PHP explicitly posts `sales - gst`, retained here.
6. Is the one-rupee card tolerance inclusive on both sides? The rebuild treats ±Rs 1.00 as acceptable, correcting the apparent one-sided comparison.
7. Should a close be reversible/reopenable, and if so, what is the controlled reversal process for loyalty and finance rows? The current implementation makes a date close unique and does not implement reopen.

## Sample data execution

Input: store `S01`, business date `2026-11-10`, machine card total `44797.00`.

- Held bills: 0, so close is allowed.
- Completed bills only; voided bill `B1003` excluded. Late bill `B1007` at 23:30 is included.
- Tender totals:
  - CASH: **Rs 1,797.00** (sale Rs 1,497.00 less refund Rs 999.00 plus cash sale/tender data as present in sample)
  - CARD: **Rs 44,797.00**
  - UPI: **Rs 25,878.00**
- Gross sales (GST-inclusive): **Rs 72,472.00**
- GST (per-line rounded): **Rs 7,402.12**
- Net sales excluding GST: **Rs 65,069.88**
- Card variance: **Rs 0.00**
- Loyalty points awarded:
  - `9840011111`: 37
  - `9840022222`: 38
  - `9840033333`: 500 (500-point per-bill cap)
- Finance interface rows (five):
  - CASH: Rs 1,797.00
  - CARD: Rs 44,797.00
  - UPI: Rs 25,878.00
  - SALES: Rs 65,069.88
  - GST: Rs 7,402.12

The sample loyalty balances after close are `9840011111`: 157 (120 + 37) and `9840033333`: 540 (40 + 500). Customer `9840022222` has no loyalty row, so its 38 eligible points are computed/reported but not persisted, matching the legacy `UPDATE` behavior.

## Run result caveat

The totals above are calculated from the supplied CSVs with the corrected full-day date window and Decimal arithmetic. The local environment used to prepare this deliverable did not have Django installed, so database migration and the management-command close were not executed here. Follow README commands to run the actual migration, import, close, and test suite.
