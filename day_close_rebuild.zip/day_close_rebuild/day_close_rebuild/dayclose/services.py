from collections import defaultdict
from datetime import datetime, time, timedelta
from decimal import Decimal, ROUND_FLOOR, ROUND_HALF_UP
from django.db import IntegrityError, transaction
from django.utils import timezone
from .models import Bill, BillTender, BillItem, DayClose, FinanceInterface, Loyalty, Store

CENT = Decimal("0.01")
ZERO = Decimal("0.00")
ONE = Decimal("1.00")
HUNDRED = Decimal("100")
SUPPORTED_TENDERS = ("CASH", "CARD", "UPI")

class DayCloseError(Exception):
    code = "day_close_error"

class HeldBillsError(DayCloseError):
    code = "held_bills"

class CardVarianceError(DayCloseError):
    code = "card_variance"
    def __init__(self, variance):
        self.variance = variance
        super().__init__(f"Card variance exceeds Rs 1.00: {variance}")

class AlreadyClosedError(DayCloseError):
    code = "already_closed"

def _money(value):
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)

@transaction.atomic
def close_day(store_code, business_date, machine_card_total, user):
    """Close one local business date atomically. Returns persisted totals and finance rows."""
    if isinstance(business_date, str):
        business_date = datetime.strptime(business_date, "%Y-%m-%d").date()
    machine_card_total = _money(machine_card_total)
    store = Store.objects.get(pk=store_code)

    # Half-open interval includes every time on the business date, including 23:59:59.
    tz = timezone.get_current_timezone()
    start = timezone.make_aware(datetime.combine(business_date, time.min), tz)
    end = timezone.make_aware(datetime.combine(business_date + timedelta(days=1), time.min), tz)

    # Lock the store row to serialize concurrent close attempts across database engines.
    Store.objects.select_for_update().get(pk=store_code)
    if DayClose.objects.filter(store=store, business_date=business_date).exists():
        raise AlreadyClosedError("This store's business date is already closed")

    bills = Bill.objects.filter(store=store, bill_datetime__gte=start, bill_datetime__lt=end)
    if bills.filter(status="H").exists():
        raise HeldBillsError("Cannot close day: there are held bills")
    completed = bills.filter(status="C")
    tender_totals = {kind: ZERO for kind in SUPPORTED_TENDERS}
    tender_rows = BillTender.objects.filter(bill__in=completed).select_related("bill")
    for tender in tender_rows.iterator():
        if tender.tender_type not in tender_totals:
            continue  # Same behavior as the PHP: unsupported tender types are not included.
        amount = _money(tender.amount)
        if tender.bill.bill_type == "REFUND":
            amount = -amount
        tender_totals[tender.tender_type] += amount
    for key in tender_totals:
        tender_totals[key] = _money(tender_totals[key])

    gross_sales = ZERO
    gst_total = ZERO
    item_rows = BillItem.objects.filter(bill__in=completed).select_related("bill")
    for item in item_rows.iterator():
        line = Decimal(item.qty) * item.mrp - item.discount
        divisor = Decimal("1") + item.gst_rate / HUNDRED
        tax = (line - line / divisor).quantize(CENT, rounding=ROUND_HALF_UP)
        if item.bill.bill_type == "REFUND":
            line, tax = -line, -tax
        gross_sales += line
        gst_total += tax
    gross_sales, gst_total = _money(gross_sales), _money(gst_total)
    net_sales = _money(gross_sales - gst_total)

    variance = _money(tender_totals["CARD"] - machine_card_total)
    if abs(variance) > ONE:
        raise CardVarianceError(variance)

    # Update existing loyalty rows only, matching legacy UPDATE semantics.
    loyalty_points = defaultdict(int)
    eligible = bills.filter(status="C", bill_type="SALE").exclude(customer_mobile__isnull=True).exclude(customer_mobile="")
    for bill in eligible.iterator():
        points = int((bill.net_amount / HUNDRED).to_integral_value(rounding=ROUND_FLOOR))
        points = min(points, 500)
        Loyalty.objects.filter(pk=bill.customer_mobile).update(points=F("points") + points)
        loyalty_points[bill.customer_mobile] += points

    close = DayClose.objects.create(
        store=store, business_date=business_date, closed_by=str(user)[:50],
        closed_at=timezone.now(), cash_total=tender_totals["CASH"],
        card_total=tender_totals["CARD"], upi_total=tender_totals["UPI"],
        machine_card_total=machine_card_total, variance=variance,
    )
    finance_amounts = {
        **tender_totals, "SALES": net_sales, "GST": gst_total,
    }
    finance_rows = [
        FinanceInterface(store=store, business_date=business_date, gl_type=kind,
                         amount=amount, created_at=timezone.now())
        for kind, amount in finance_amounts.items()
    ]
    FinanceInterface.objects.bulk_create(finance_rows)
    return {
        "day_close": close, "tender_totals": tender_totals,
        "gross_sales": gross_sales, "gst": gst_total, "net_sales": net_sales,
        "loyalty_points": dict(loyalty_points), "finance_amounts": finance_amounts,
    }

from django.db.models import F
