import csv
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone
from dayclose.models import Store, Bill, BillItem, BillTender, Loyalty

class Command(BaseCommand):
    help = "Load the supplied CSV sample data (replace existing rows for imported primary keys)."
    def add_arguments(self, parser):
        parser.add_argument("--data-dir", default="sample_data")
    @transaction.atomic
    def handle(self, *args, **opts):
        base = Path(opts["data_dir"])
        def rows(name):
            with (base / name).open(newline="", encoding="utf-8-sig") as f:
                return list(csv.DictReader(f))
        for r in rows("stores.csv"):
            Store.objects.update_or_create(store_code=r["store_code"], defaults={"store_name":r["store_name"]})
        for r in rows("bills.csv"):
            mobile = (r.get("customer_mobile") or "").strip()
            if mobile.lower() in ("nan", "none"): mobile = ""
            Bill.objects.update_or_create(bill_no=r["bill_no"], defaults={
                "store_id":r["store_code"], "bill_datetime":timezone.make_aware(datetime.strptime(r["bill_datetime"], "%Y-%m-%d %H:%M:%S")),
                "status":r["status"], "bill_type":r["bill_type"], "customer_mobile":mobile or None,
                "net_amount":Decimal(r["net_amount"]),
            })
        BillItem.objects.all().delete()
        for r in rows("bill_items.csv"):
            BillItem.objects.create(bill_id=r["bill_no"], sku=r["sku"], qty=int(r["qty"]),
                mrp=Decimal(r["mrp"]), discount=Decimal(r["discount"]), gst_rate=Decimal(r["gst_rate"]))
        BillTender.objects.all().delete()
        for r in rows("bill_tenders.csv"):
            BillTender.objects.create(bill_id=r["bill_no"], tender_type=r["tender_type"], amount=Decimal(r["amount"]))
        for r in rows("loyalty.csv"):
            Loyalty.objects.update_or_create(customer_mobile=r["customer_mobile"], defaults={"points":int(r["points"])})
        self.stdout.write(self.style.SUCCESS("Sample data loaded"))
