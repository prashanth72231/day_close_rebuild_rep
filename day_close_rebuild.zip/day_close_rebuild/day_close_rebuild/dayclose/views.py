from decimal import Decimal
from django.core.exceptions import ObjectDoesNotExist
from django.db import IntegrityError
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import DayCloseRequestSerializer
from .services import close_day, DayCloseError, HeldBillsError, CardVarianceError, AlreadyClosedError
class DayCloseView(APIView):
    def post(self, request):
        serializer = DayCloseRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = request.user.get_username() if request.user.is_authenticated else "api"
        try:
            result = close_day(user=user, **serializer.validated_data)
        except ObjectDoesNotExist:
            return Response({"error": "store_not_found"}, status=status.HTTP_404_NOT_FOUND)
        except HeldBillsError as exc:
            return Response({"error": exc.code, "detail": str(exc)}, status=status.HTTP_409_CONFLICT)
        except CardVarianceError as exc:
            return Response({"error": exc.code, "detail": str(exc), "variance": str(exc.variance)}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)
        except AlreadyClosedError as exc:
            return Response({"error": exc.code, "detail": str(exc)}, status=status.HTTP_409_CONFLICT)
        except IntegrityError:
            return Response({"error": "already_closed"}, status=status.HTTP_409_CONFLICT)
        close = result["day_close"]
        return Response({
            "status": "closed", "store_code": close.store_id,
            "business_date": str(close.business_date),
            "tender_totals": {k: str(v) for k, v in result["tender_totals"].items()},
            "gross_sales": str(result["gross_sales"]), "net_sales": str(result["net_sales"]),
            "gst": str(result["gst"]),
            "loyalty_points": result["loyalty_points"],
            "finance_rows": {k: str(v) for k, v in result["finance_amounts"].items()},
            "variance": str(close.variance),
        }, status=status.HTTP_201_CREATED)
