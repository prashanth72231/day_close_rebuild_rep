from django.db import models

class Store(models.Model):
    store_code = models.CharField(max_length=10, primary_key=True)
    store_name = models.CharField(max_length=100, blank=True)
    class Meta:
        db_table = "stores"

class Bill(models.Model):
    bill_no = models.CharField(max_length=20, primary_key=True)
    store = models.ForeignKey(Store, db_column="store_code", on_delete=models.PROTECT, related_name="bills")
    bill_datetime = models.DateTimeField()
    status = models.CharField(max_length=1)  # C/H/V
    bill_type = models.CharField(max_length=10)  # SALE/REFUND
    customer_mobile = models.CharField(max_length=15, blank=True, null=True)
    net_amount = models.DecimalField(max_digits=12, decimal_places=2)
    class Meta:
        db_table = "bills"
        indexes = [models.Index(fields=["store", "bill_datetime", "status"])]

class BillItem(models.Model):
    bill = models.ForeignKey(Bill, db_column="bill_no", on_delete=models.CASCADE, related_name="items")
    sku = models.CharField(max_length=20)
    qty = models.IntegerField()
    mrp = models.DecimalField(max_digits=12, decimal_places=2)
    discount = models.DecimalField(max_digits=12, decimal_places=2)
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2)
    class Meta:
        db_table = "bill_items"

class BillTender(models.Model):
    bill = models.ForeignKey(Bill, db_column="bill_no", on_delete=models.CASCADE, related_name="tenders")
    tender_type = models.CharField(max_length=10)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    class Meta:
        db_table = "bill_tenders"

class Loyalty(models.Model):
    customer_mobile = models.CharField(max_length=15, primary_key=True)
    points = models.IntegerField(default=0)
    class Meta:
        db_table = "loyalty"

class DayClose(models.Model):
    store = models.ForeignKey(Store, db_column="store_code", on_delete=models.PROTECT)
    business_date = models.DateField()
    closed_by = models.CharField(max_length=50)
    closed_at = models.DateTimeField()
    cash_total = models.DecimalField(max_digits=12, decimal_places=2)
    card_total = models.DecimalField(max_digits=12, decimal_places=2)
    upi_total = models.DecimalField(max_digits=12, decimal_places=2)
    machine_card_total = models.DecimalField(max_digits=12, decimal_places=2)
    variance = models.DecimalField(max_digits=12, decimal_places=2)
    class Meta:
        db_table = "day_close"
        constraints = [models.UniqueConstraint(fields=["store", "business_date"], name="uniq_day_close_store_date")]

class FinanceInterface(models.Model):
    store = models.ForeignKey(Store, db_column="store_code", on_delete=models.PROTECT)
    business_date = models.DateField()
    gl_type = models.CharField(max_length=10)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    created_at = models.DateTimeField()
    class Meta:
        db_table = "fin_interface"
