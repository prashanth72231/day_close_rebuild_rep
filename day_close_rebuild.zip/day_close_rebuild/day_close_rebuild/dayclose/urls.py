from django.urls import path
from .views import DayCloseView
urlpatterns = [path("day-close/", DayCloseView.as_view(), name="day-close")]
