from datetime import date, datetime
from decimal import Decimal
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient
from .models import Store, Bill, BillItem, BillTender, Loyalty, DayClose, FinanceInterface
from .services import close_day, HeldBillsError, CardVarianceError, AlreadyClosedError

class DayCloseTests(TestCase):
    def setUp(self):
        self.store = Store.objects.create(store_code="S01", store_name="Test")
    def bill(self, no, at="2026-11-10 12:00:00", status="C", kind="SALE", mobile=None, net="250.00"):
        return Bill.objects.create(bill_no=no, store=self.store,
            bill_datetime=timezone.make_aware(datetime.strptime(at,"%Y-%m-%d %H:%M:%S")),
            status=status, bill_type=kind, customer_mobile=mobile, net_amount=Decimal(net))
    def test_full_day_includes_late_bill_and_refunds(self):
        sale=self.bill("1",at="2026-11-10 23:59:59",net="250")
        BillTender.objects.create(bill=sale,tender_type="CARD",amount="250")
        refund=self.bill("2",kind="REFUND",net="50")
        BillTender.objects.create(bill=refund,tender_type="CARD",amount="50")
        result=close_day("S01",date(2026,11,10),"200","manager")
        self.assertEqual(result["tender_totals"]["CARD"],Decimal("200.00"))
    def test_held_bill_blocks_close(self):
        self.bill("H",status="H")
        with self.assertRaises(HeldBillsError): close_day("S01",date(2026,11,10),"0","m")
        self.assertEqual(DayClose.objects.count(),0)
    def test_negative_card_variance_is_checked(self):
        sale=self.bill("1")
        BillTender.objects.create(bill=sale,tender_type="CARD",amount="100")
        with self.assertRaises(CardVarianceError): close_day("S01",date(2026,11,10),"102","m")
    def test_exact_one_rupee_variance_is_allowed_both_directions(self):
        sale=self.bill("1")
        BillTender.objects.create(bill=sale,tender_type="CARD",amount="100")
        close_day("S01",date(2026,11,10),"101","m")
    def test_gst_is_rounded_per_line_and_refund_reverses(self):
        sale=self.bill("1")
        BillItem.objects.create(bill=sale,sku="A",qty=1,mrp="105",discount="0",gst_rate="5")
        result=close_day("S01",date(2026,11,10),"0","m")
        self.assertEqual(result["gst"],Decimal("5.00"))
        self.assertEqual(result["net_sales"],Decimal("100.00"))
    def test_loyalty_floor_and_cap_and_missing_account_no_crash(self):
        sale=self.bill("1",mobile="999",net="60000")
        Loyalty.objects.create(customer_mobile="999",points=10)
        result=close_day("S01",date(2026,11,10),"0","m")
        self.assertEqual(Loyalty.objects.get(pk="999").points,510)
        self.assertEqual(result["loyalty_points"]["999"],500)
    def test_duplicate_close_rejected(self):
        self.bill("1")
        close_day("S01",date(2026,11,10),"0","m")
        with self.assertRaises(AlreadyClosedError): close_day("S01",date(2026,11,10),"0","m")
    def test_api_validation_and_success(self):
        self.bill("1")
        client=APIClient()
        response=client.post("/api/day-close/",{"store_code":"S01","business_date":"2026-11-10","machine_card_total":"0.00"},format="json")
        self.assertEqual(response.status_code,201)
        self.assertEqual(FinanceInterface.objects.count(),5)
