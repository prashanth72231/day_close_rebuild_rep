# Django day-close rebuild

Python 3.11+, Django, and Django REST Framework implementation of the supplied PHP day-close feature.

## Setup (SQLite)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations dayclose
python manage.py migrate
python manage.py load_sample_data --data-dir sample_data
python manage.py test
```

## Close the supplied sample day

```bash
python manage.py shell -c "from dayclose.services import close_day; r=close_day('S01','2026-11-10','44797.00','sample-manager'); print({k:str(v) for k,v in r['finance_amounts'].items()})"
```

Expected amounts are documented in `NOTES.md`. The date can only be closed once; reload a fresh database (or clear that date's day-close and finance rows and restore loyalty balances) before rerunning the command.

## API

`POST /api/day-close/` with JSON:

```json
{
  "store_code": "S01",
  "business_date": "2026-11-10",
  "machine_card_total": "44797.00"
}
```

The caller's authenticated username is recorded as `closed_by`; unauthenticated local API calls use `api`. Successful response is HTTP 201 with tender totals, sales, GST, loyalty points, and finance amounts. Validation failures return 400; held/duplicate close returns 409; card variance beyond tolerance returns 422; unknown store returns 404.

For local testing:

```bash
python manage.py runserver
```

## MySQL

Create a database and set:

```bash
DB_ENGINE=mysql
DB_NAME=dayclose
DB_USER=...
DB_PASSWORD=...
DB_HOST=127.0.0.1
DB_PORT=3306
```

Install `mysqlclient` using the platform's MySQL development headers, then run the same `makemigrations` and `migrate` commands. The service uses Django ORM, transactions, Decimal fields, and portable constraints; no SQLite-specific SQL is used.

## Notes

See `NOTES.md` for business rules, legacy defects and fixes, unresolved business questions, and sample totals.
